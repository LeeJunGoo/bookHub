내일배움 캠프 2조 newsfeed BookHub 입니다.

notion - (https://www.notion.so/2-S-A-2b483b093c414398bf3c2aa44ea07cab)
